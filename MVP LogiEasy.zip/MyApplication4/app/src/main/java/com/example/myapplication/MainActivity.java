package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText quantidadeProduto1 = (EditText)findViewById(R.id.quantidadeProduto1);
        quantidadeProduto1.addTextChangedListener(new TextWatcher() {
            EditText textoPesquisa = (EditText) findViewById(R.id.textoPesquisa);
            TextView precoProduto1 = (TextView)findViewById(R.id.precoProduto1);
            EditText quantidadeProduto1 = (EditText)findViewById(R.id.quantidadeProduto1);
            EditText quantidadeProduto2 = (EditText)findViewById(R.id.quantidadeProduto2);
            TextView valorTotal = (TextView)findViewById(R.id.valorTotal);
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (textoPesquisa.getText().toString().equalsIgnoreCase("arroz") && s.length()!=0){
                    String str = "R$ "+ (Integer.valueOf(s.toString()) * 5);
                    precoProduto1.setText(str);

                    valorTotal.setVisibility(View.VISIBLE);
                    double valor;
                    if (quantidadeProduto2.getText().toString().length() != 0) {
                        valor = Integer.valueOf(quantidadeProduto1.getText().toString()) * 5 + Integer.valueOf(quantidadeProduto2.getText().toString()) * 5.3;
                        valorTotal.setText("Valor Total: R$ " + valor);
                    }else {
                        valor = Integer.valueOf(quantidadeProduto1.getText().toString()) * 5 + 0 * 5.3;
                        valorTotal.setText("Valor Total: R$ " + valor);
                    }
                }else if (textoPesquisa.getText().toString().equalsIgnoreCase("arroz") && s.length()==0){
                    precoProduto1.setText("R$ 5,00");

                    valorTotal.setVisibility(View.VISIBLE);
                    double valor;
                    if (quantidadeProduto2.getText().toString().length() != 0) {
                        valor = Integer.valueOf(quantidadeProduto2.getText().toString()) * 5.3;
                        valorTotal.setText("Valor Total: R$ " + valor);
                    }else {
                        valorTotal.setText("Valor Total: R$ 0,00");
                    }
                }

                if (textoPesquisa.getText().toString().equalsIgnoreCase("shampoo") && s.length()!=0){
                    String str = "R$ "+ (Integer.valueOf(quantidadeProduto1.getText().toString()) * 7);
                    precoProduto1.setText(str);

                    valorTotal.setVisibility(View.VISIBLE);
                    double valor;
                    if (quantidadeProduto2.getText().toString().length() != 0) {
                        valor = Integer.valueOf(quantidadeProduto1.getText().toString()) * 7 + Integer.valueOf(quantidadeProduto2.getText().toString()) * 6.35;
                        valorTotal.setText("Valor Total: R$ " + valor);
                    }else {
                        valor = Integer.valueOf(quantidadeProduto1.getText().toString()) * 7 + 0 * 6.35;
                        valorTotal.setText("Valor Total: R$ " + valor);
                    }
                }else if (textoPesquisa.getText().toString().equalsIgnoreCase("shampoo") && s.length()==0){
                    precoProduto1.setText("R$ 7,00");

                    valorTotal.setVisibility(View.VISIBLE);
                    double valor;
                    if (quantidadeProduto2.getText().toString().length() != 0) {
                        valor = Integer.valueOf(quantidadeProduto2.getText().toString()) * 6.35;
                        valorTotal.setText("Valor Total: R$ " + valor);
                    }else {
                        valorTotal.setText("Valor Total: R$ 0,00");
                    }
                }
            }
        });



        EditText quantidadeProduto2 = (EditText)findViewById(R.id.quantidadeProduto2);
        quantidadeProduto2.addTextChangedListener(new TextWatcher() {
            TextView precoProduto2 = (TextView)findViewById(R.id.precoProduto2);
            EditText textoPesquisa = (EditText) findViewById(R.id.textoPesquisa);
            EditText quantidadeProduto1 = (EditText)findViewById(R.id.quantidadeProduto1);
            EditText quantidadeProduto2 = (EditText)findViewById(R.id.quantidadeProduto2);
            TextView valorTotal = (TextView)findViewById(R.id.valorTotal);
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if (textoPesquisa.getText().toString().equalsIgnoreCase("arroz") && s.length()!=0){
                    String str = "R$ "+ (Integer.valueOf(quantidadeProduto2.getText().toString()) * 5.3);
                    precoProduto2.setText(str);

                    valorTotal.setVisibility(View.VISIBLE);
                    double valor;
                    if (quantidadeProduto1.getText().toString().length() != 0) {
                        valor = Integer.valueOf(quantidadeProduto1.getText().toString()) * 5 + Integer.valueOf(quantidadeProduto2.getText().toString()) * 5.3;
                        valorTotal.setText("Valor Total: R$ " + valor);
                    }else {
                        valor = Integer.valueOf(quantidadeProduto2.getText().toString()) * 5.3;
                        valorTotal.setText("Valor Total: R$ " + valor);
                    }
                }else if (textoPesquisa.getText().toString().equalsIgnoreCase("arroz") && s.length()==0){
                    precoProduto2.setText("R$ 5,30");

                    valorTotal.setVisibility(View.VISIBLE);
                    double valor;
                    if (quantidadeProduto1.getText().toString().length() != 0) {
                        valor = Integer.valueOf(quantidadeProduto1.getText().toString()) * 5;
                        valorTotal.setText("Valor Total: R$ " + valor);
                    }else {
                        valorTotal.setText("Valor Total: R$ 0,00");
                    }
                }

                if (textoPesquisa.getText().toString().equalsIgnoreCase("shampoo") && s.length()!=0){
                    String str = "R$ "+ (Integer.valueOf(quantidadeProduto2.getText().toString()) * 6.35);
                    precoProduto2.setText(str);

                    valorTotal.setVisibility(View.VISIBLE);
                    double valor;
                    if (quantidadeProduto1.getText().toString().length() != 0) {
                        valor = Integer.valueOf(quantidadeProduto1.getText().toString()) * 7 + Integer.valueOf(quantidadeProduto2.getText().toString()) * 6.35;
                        valorTotal.setText("Valor Total: R$ " + valor);
                    }else {
                        valor = Integer.valueOf(quantidadeProduto2.getText().toString()) * 6.35;
                        valorTotal.setText("Valor Total: R$ " + valor);
                    }
                }else if (textoPesquisa.getText().toString().equalsIgnoreCase("shampoo") && s.length()==0){
                    valorTotal.setVisibility(View.VISIBLE);
                    double valor;
                    if (quantidadeProduto1.getText().toString().length() != 0) {
                        valor = Integer.valueOf(quantidadeProduto1.getText().toString()) * 7;
                        valorTotal.setText("Valor Total: R$ " + valor);
                    }else {
                        valorTotal.setText("Valor Total: R$ 0,00");
                    }
                    precoProduto2.setText("R$ 6,35");
                }
            }
        });

    }

    public void pesquisaProduto (View view){

        //Declarando objetos
        EditText textoPesquisa = (EditText) findViewById(R.id.textoPesquisa);
        ImageView produto1 = (ImageView)findViewById(R.id.Produto1);
        ImageView produto2 = (ImageView)findViewById(R.id.Produto2);
        TextView descricaoProduto1 = (TextView)findViewById(R.id.descricaoProduto1);
        TextView precoProduto1 = (TextView)findViewById(R.id.precoProduto1);
        EditText quantidadeProduto1 = (EditText) findViewById(R.id.quantidadeProduto1);
        TextView descricaoProduto2 = (TextView)findViewById(R.id.descricaoProduto2);
        TextView precoProduto2 = (TextView)findViewById(R.id.precoProduto2);
        EditText quantidadeProduto2 = (EditText)findViewById(R.id.quantidadeProduto2);
        TextView staticText = (TextView)findViewById(R.id.staticText);
        TextView staticText2 = (TextView)findViewById(R.id.staticText2);
        TextView staticText3 = (TextView)findViewById(R.id.staticText3);
        TextView staticText4 = (TextView)findViewById(R.id.staticText4);
        TextView valorTotal = (TextView)findViewById(R.id.valorTotal);

        //Se for arroz
        if (textoPesquisa.getText().toString().equalsIgnoreCase("arroz")){
            valorTotal.setVisibility(View.INVISIBLE);
            quantidadeProduto1.setText("");
            quantidadeProduto2.setText("");

            produto1.setImageDrawable(getResources().getDrawable(R.drawable.arroz_camil));
            produto1.setVisibility(View.VISIBLE);

            produto2.setImageDrawable(getResources().getDrawable(R.drawable.arroz_tio_joao));
            produto2.setVisibility(View.VISIBLE);

            descricaoProduto1.setText("Arroz Camil 5kg");
            descricaoProduto1.setVisibility(View.VISIBLE);
            //quantidadeProduto1.setText("1");
            quantidadeProduto1.setVisibility(View.VISIBLE);
            precoProduto1.setText("R$ 5,00");
            precoProduto1.setVisibility(View.VISIBLE);

            staticText.setVisibility(View.VISIBLE);
            staticText2.setVisibility(View.VISIBLE);

            descricaoProduto2.setText("Arroz Tio João 5kg");
            descricaoProduto2.setVisibility(View.VISIBLE);
            //quantidadeProduto2.setText("1");
            quantidadeProduto2.setVisibility(View.VISIBLE);
            precoProduto2.setText("R$ 5,30");
            precoProduto2.setVisibility(View.VISIBLE);

            staticText3.setVisibility(View.VISIBLE);
            staticText4.setVisibility(View.VISIBLE);

        //Se for shampoo
        }else if (textoPesquisa.getText().toString().equalsIgnoreCase("shampoo")){
            valorTotal.setVisibility(View.INVISIBLE);
            quantidadeProduto1.setText("");
            quantidadeProduto2.setText("");

            produto1.setImageDrawable(getResources().getDrawable(R.drawable.shampoo_dove));
            produto1.setVisibility(View.VISIBLE);

            produto2.setImageDrawable(getResources().getDrawable(R.drawable.shampoo_seda));
            produto2.setVisibility(View.VISIBLE);

            descricaoProduto1.setText("Shampoo Dove");
            descricaoProduto1.setVisibility(View.VISIBLE);
            //quantidadeProduto1.setText("1");
            quantidadeProduto1.setVisibility(View.VISIBLE);
            precoProduto1.setText("R$ 7,00");
            precoProduto1.setVisibility(View.VISIBLE);

            staticText.setVisibility(View.VISIBLE);
            staticText2.setVisibility(View.VISIBLE);


            descricaoProduto2.setText("ShampooSeda");
            descricaoProduto2.setVisibility(View.VISIBLE);
            //quantidadeProduto2.setText("1");
            quantidadeProduto2.setVisibility(View.VISIBLE);
            precoProduto2.setText("R$ 6,35");
            precoProduto2.setVisibility(View.VISIBLE);

            staticText3.setVisibility(View.VISIBLE);
            staticText4.setVisibility(View.VISIBLE);

        }else{
            descricaoProduto1.setText("NENHUM PRODUTO ENCONTRADO");
            descricaoProduto1.setVisibility(View.VISIBLE);

            valorTotal.setVisibility(View.INVISIBLE);
            produto1.setVisibility(View.INVISIBLE);
            produto2.setVisibility(View.INVISIBLE);
            quantidadeProduto1.setVisibility(View.INVISIBLE);
            precoProduto1.setVisibility(View.INVISIBLE);
            descricaoProduto2.setVisibility(View.INVISIBLE);
            quantidadeProduto2.setVisibility(View.INVISIBLE);
            precoProduto2.setVisibility(View.INVISIBLE);
            staticText.setVisibility(View.INVISIBLE);
            staticText2.setVisibility(View.INVISIBLE);
            staticText3.setVisibility(View.INVISIBLE);
            staticText4.setVisibility(View.INVISIBLE);
        }
    }


    public void tornarInvisivelViews (){
        ImageView produto1 = (ImageView)findViewById(R.id.Produto1);
        ImageView produto2 = (ImageView)findViewById(R.id.Produto2);
        TextView descricaoProduto1 = (TextView)findViewById(R.id.descricaoProduto1);
        TextView precoProduto1 = (TextView)findViewById(R.id.precoProduto1);
        EditText quantidadeProduto1 = (EditText) findViewById(R.id.quantidadeProduto1);
        TextView descricaoProduto2 = (TextView)findViewById(R.id.descricaoProduto2);
        TextView precoProduto2 = (TextView)findViewById(R.id.precoProduto2);
        EditText quantidadeProduto2 = (EditText)findViewById(R.id.quantidadeProduto2);
        TextView staticText = (TextView)findViewById(R.id.staticText);
        TextView staticText2 = (TextView)findViewById(R.id.staticText2);
        TextView staticText3 = (TextView)findViewById(R.id.staticText3);
        TextView staticText4 = (TextView)findViewById(R.id.staticText4);
        TextView valorTotal = (TextView)findViewById(R.id.valorTotal);

        produto1.setVisibility(View.INVISIBLE);
        produto2.setVisibility(View.INVISIBLE);
        descricaoProduto1.setVisibility(View.INVISIBLE);
        precoProduto1.setVisibility(View.INVISIBLE);
        quantidadeProduto1.setVisibility(View.INVISIBLE);
        precoProduto2.setVisibility(View.INVISIBLE);
        quantidadeProduto2.setVisibility(View.INVISIBLE);
        descricaoProduto2.setVisibility(View.INVISIBLE);
        staticText.setVisibility(View.INVISIBLE);
        staticText2.setVisibility(View.INVISIBLE);
        staticText3.setVisibility(View.INVISIBLE);
        staticText4.setVisibility(View.INVISIBLE);
        valorTotal.setVisibility(View.INVISIBLE);
    }

    public void comprarProdutos(View view){

        EditText textoPesquisa = (EditText) findViewById(R.id.textoPesquisa);
        TextView descricaoProduto1 = (TextView)findViewById(R.id.descricaoProduto1);
        EditText quantidadeProduto1 = (EditText) findViewById(R.id.quantidadeProduto1);
        EditText quantidadeProduto2 = (EditText)findViewById(R.id.quantidadeProduto2);
        TextView valorTotal = (TextView)findViewById(R.id.valorTotal);

        //Se for arroz
        if (textoPesquisa.getText().toString().equalsIgnoreCase("arroz")){
            if (quantidadeProduto1.getText().toString().length() != 0 && quantidadeProduto2.getText().toString().length() != 0){
                double valor = Integer.valueOf(quantidadeProduto1.getText().toString()) * 5 + Integer.valueOf(quantidadeProduto2.getText().toString()) * 5.3;
                descricaoProduto1.setText("Compra realizada no valor de R$ " + valor);
                tornarInvisivelViews();
                descricaoProduto1.setVisibility(View.VISIBLE);
            }else if (quantidadeProduto1.getText().toString().length() != 0){
                double valor = Integer.valueOf(quantidadeProduto1.getText().toString()) * 5;
                descricaoProduto1.setText("Compra realizada no valor de R$ " + valor);
                tornarInvisivelViews();
                descricaoProduto1.setVisibility(View.VISIBLE);
            }else if (quantidadeProduto2.getText().toString().length() != 0) {
                double valor = Integer.valueOf(quantidadeProduto2.getText().toString()) * 5.3;
                descricaoProduto1.setText("Compra realizada no valor de R$ " + valor);
                tornarInvisivelViews();
                descricaoProduto1.setVisibility(View.VISIBLE);
            }else {
                valorTotal.setText("Por favor escolher a quantidade de produtos!");
            }

        }//Se for shampoo
        else if (textoPesquisa.getText().toString().equalsIgnoreCase("shampoo")){
            if (quantidadeProduto1.getText().toString().length() != 0 && quantidadeProduto2.getText().toString().length() != 0){
                double valor = Integer.valueOf(quantidadeProduto1.getText().toString()) * 7 + Integer.valueOf(quantidadeProduto2.getText().toString()) * 6.35;
                descricaoProduto1.setText("Compra realizada no valor de R$ " + valor);
                tornarInvisivelViews();
                descricaoProduto1.setVisibility(View.VISIBLE);
            }else if (quantidadeProduto1.getText().toString().length() != 0){
                double valor = Integer.valueOf(quantidadeProduto1.getText().toString()) * 7;
                descricaoProduto1.setText("Compra realizada no valor de R$ " + valor);
                tornarInvisivelViews();
                descricaoProduto1.setVisibility(View.VISIBLE);
            }else if (quantidadeProduto2.getText().toString().length() != 0) {
                double valor = Integer.valueOf(quantidadeProduto2.getText().toString()) * 6.35;
                descricaoProduto1.setText("Compra realizada no valor de R$ " + valor);
                tornarInvisivelViews();
                descricaoProduto1.setVisibility(View.VISIBLE);
            }else {
                valorTotal.setText("Por favor escolher a quantidade de produtos!");
            }
        }

    }
}
